import{_ as e,d as t,y as r}from"./v-preact-BAP1wjwx.js";import{h as a}from"./v-misc-CJ9EBB9u.js";import{t as s}from"./c-dash-vS3BZ9jl.js";import{_ as d}from"./v-ui-BuZZnogH.js";const i=a.bind(e),l="RESET";function o({isOpen:e,onClose:a,onConfirm:o}){const[n,g]=t(""),[p,c]=t(10),[b,u]=t(!1);r(()=>{e&&(g(""),c(10),u(!1))},[e]),r(()=>{if(!e||0===p)return;const t=setInterval(()=>{c(e=>Math.max(0,e-1))},1e3);return()=>clearInterval(t)},[e,p]);const x=n===l&&0===p&&!b;return i`
    <${d}
      open=${e}
      onClose=${()=>!b&&a()}
      class="relative z-50"
    >
      <!-- Backdrop -->
      <div class="fixed inset-0 bg-black/50 backdrop-blur-sm" aria-hidden="true"></div>

      <!-- Full-screen container -->
      <div class="fixed inset-0 flex items-center justify-center p-4">
        <!-- Modal panel -->
        <${d.Panel} class="mx-auto max-w-lg w-full bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 animate-fade-in">
          <!-- Warning Icon -->
          <div class="bg-red-100 dark:bg-red-900/20 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
            <span class="text-4xl">🚨</span>
          </div>

          <!-- Title -->
          <${d.Title} class="text-2xl font-bold text-center text-gray-900 dark:text-white mb-3">
            Factory Reset
          <//>

          <!-- Warning Message -->
          <div class="bg-red-50 dark:bg-red-900/10 border-2 border-red-200 dark:border-red-800 rounded-lg p-4 mb-4">
            <p class="text-red-800 dark:text-red-200 font-semibold mb-2">
              ⚠️ This action cannot be undone!
            </p>
            <p class="text-red-700 dark:text-red-300 text-sm">
              Factory reset will:
            </p>
            <ul class="text-red-700 dark:text-red-300 text-sm list-disc list-inside mt-2 space-y-1">
              <li>Delete all configuration settings</li>
              <li>Clear WiFi and MQTT credentials</li>
              <li>Reset PID parameters to defaults</li>
              <li>Clear all preset configurations</li>
              <li>Erase temperature history data</li>
            </ul>
          </div>

          <!-- Countdown Timer -->
          ${p>0&&i`
            <div class="bg-orange-50 dark:bg-orange-900/10 border border-orange-200 dark:border-orange-800 rounded-lg p-3 mb-4 text-center">
              <p class="text-orange-700 dark:text-orange-300 font-medium">
                Please wait ${p} second${1!==p?"s":""} before confirming...
              </p>
              <div class="mt-2 h-2 bg-orange-200 dark:bg-orange-800 rounded-full overflow-hidden">
                <div
                  class="h-full bg-orange-500 transition-all duration-1000 ease-linear"
                  style="width: ${(10-p)/10*100}%"
                ></div>
              </div>
            </div>
          `}

          <!-- Type-to-Confirm Input -->
          <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Type <span class="font-mono font-bold text-red-600 dark:text-red-400">${l}</span> to confirm:
            </label>
            <input
              type="text"
              value=${n}
              onInput=${e=>g(e.target.value.toUpperCase())}
              disabled=${b||p>0}
              placeholder=${p>0?"Waiting for countdown...":`Type "${l}"`}
              class="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border-2 ${n===l?"border-red-500 dark:border-red-400":"border-gray-300 dark:border-gray-600"} rounded-lg text-gray-900 dark:text-white font-mono font-bold text-center text-lg focus:outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            />
            ${n&&n!==l&&i`
              <p class="mt-2 text-sm text-red-600 dark:text-red-400">
                Text does not match. Please type exactly: ${l}
              </p>
            `}
            ${n===l&&0===p&&i`
              <p class="mt-2 text-sm text-green-600 dark:text-green-400 flex items-center gap-1">
                <span>✓</span>
                <span>Confirmed. You may now proceed.</span>
              </p>
            `}
          </div>

          <!-- Actions -->
          <div class="flex gap-3">
            <button
              onClick=${a}
              disabled=${b}
              class="flex-1 px-4 py-3 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-900 dark:text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Cancel
            </button>
            <button
              onClick=${async()=>{if(x){u(!0);try{await o(),s.success("Factory reset completed successfully"),a()}catch(e){s.error(`Factory reset failed: ${e.message}`)}finally{u(!1)}}}}
              disabled=${!x}
              class="flex-1 px-4 py-3 ${x?"bg-red-500 hover:bg-red-600":"bg-gray-400 dark:bg-gray-600"} text-white rounded-lg font-medium transition-colors disabled:cursor-not-allowed"
            >
              ${b?"Resetting...":"Factory Reset"}
            </button>
          </div>
        <//>
      </div>
    <//>
  `}const n=a.bind(e);function g({label:e,value:a,onChange:s,validator:d,type:i="text",step:l,placeholder:o,required:g=!1,helpText:p}){const[c,b]=t(!1),[u,x]=t({isValid:!0,error:null});r(()=>{if(d&&""!==a&&null!=a){const e=d(a);x(e)}else g||""!==a&&null!=a||x({isValid:!0,error:null})},[a,d,g]);const y=c&&!u.isValid,m=c&&u.isValid&&""!==a&&null!==a;return n`
    <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
        ${e}
        ${g&&n`<span class="text-red-500 ml-1">*</span>`}
      </label>

      <div class="relative">
        <input
          type=${i}
          step=${l}
          value=${a}
          onInput=${e=>s(e.target.value)}
          onBlur=${()=>{b(!0)}}
          placeholder=${o}
          class="${y?"border-red-500 focus:ring-red-500":m?"border-green-500 focus:ring-green-500":"border-gray-300 dark:border-gray-600 focus:ring-primary-500"} w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 transition-all"
        />

        <!-- Validation Icon -->
        ${y&&n`
          <div class="absolute right-3 top-1/2 transform -translate-y-1/2 text-red-500">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
            </svg>
          </div>
        `}
        ${m&&n`
          <div class="absolute right-3 top-1/2 transform -translate-y-1/2 text-green-500">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
            </svg>
          </div>
        `}
      </div>

      <!-- Error Message -->
      ${y&&n`
        <p class="mt-1 text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
          <span>⚠️</span>
          <span>${u.error}</span>
        </p>
      `}

      <!-- Help Text -->
      ${p&&!y&&n`
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          ${p}
        </p>
      `}
    </div>
  `}const p=a.bind(e);function c({size:e="md",color:t="primary",label:r,fullscreen:a=!1}){const s=p`
    <div
      class="${{sm:"w-4 h-4 border-2",md:"w-8 h-8 border-2",lg:"w-12 h-12 border-3",xl:"w-16 h-16 border-4"}[e]} ${{primary:"border-primary-500 border-t-transparent",white:"border-white border-t-transparent",gray:"border-gray-400 dark:border-gray-600 border-t-transparent"}[t]} rounded-full animate-spin"
      role="status"
      aria-label=${r||"Loading..."}
    ></div>
  `;return a?p`
      <div class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-8 flex flex-col items-center gap-4">
          ${s}
          ${r&&p`
            <p class="text-gray-700 dark:text-gray-300 font-medium">${r}</p>
          `}
        </div>
      </div>
    `:r?p`
      <div class="flex items-center gap-3">
        ${s}
        <span class="text-gray-700 dark:text-gray-300">${r}</span>
      </div>
    `:s}function b(e,t){const r=parseFloat(e);if(isNaN(r))return{isValid:!1,error:"Must be a valid number"};switch(t.toLowerCase()){case"kp":if(r<.1||r>100)return{isValid:!1,error:"Kp must be between 0.1 and 100"};break;case"ki":if(r<0||r>10)return{isValid:!1,error:"Ki must be between 0 and 10"};break;case"kd":if(r<0||r>10)return{isValid:!1,error:"Kd must be between 0 and 10"};break;default:return{isValid:!1,error:"Unknown PID parameter"}}return{isValid:!0,error:null}}function u(e){return e&&0!==e.trim().length?e.length>32?{isValid:!1,error:"SSID cannot exceed 32 characters"}:{isValid:!0,error:null}:{isValid:!1,error:"SSID cannot be empty"}}function x(e){return e&&0!==e.trim().length?/^[a-zA-Z0-9.-]+$/.test(e)?{isValid:!0,error:null}:{isValid:!1,error:"Invalid broker address format"}:{isValid:!1,error:"Broker address cannot be empty"}}function y(e){const t=parseInt(e);return isNaN(t)?{isValid:!1,error:"Must be a valid number"}:t<1||t>65535?{isValid:!1,error:"Port must be between 1 and 65535"}:{isValid:!0,error:null}}const m=a.bind(e);function v({isOpen:e,onClose:r,onComplete:a}){const[d,i]=t(0),[l,o]=t(!1),[n,p]=t({ssid:"",password:""}),[v,k]=t({broker:"",port:"1883",username:"",password:""}),[f,h]=t({kp:"2.0",ki:"0.5",kd:"1.0"}),w=[{id:"wifi",title:"WiFi Setup",icon:"📡"},{id:"mqtt",title:"MQTT Setup",icon:"📨"},{id:"sensors",title:"Sensor Setup",icon:"🌡️"},{id:"review",title:"Review & Save",icon:"✅"}];return e?m`
    <div class="fixed inset-0 z-50 overflow-y-auto">
      <!-- Backdrop -->
      <div class="fixed inset-0 bg-black bg-opacity-50 transition-opacity"></div>

      <!-- Modal -->
      <div class="flex min-h-full items-center justify-center p-4">
        <div class="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-3xl w-full p-8 animate-slideUp">
          <!-- Header -->
          <div class="mb-8">
            <h2 class="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Setup Wizard
            </h2>
            <p class="text-gray-600 dark:text-gray-400">
              Let's configure your ESP32 Thermostat step by step
            </p>
          </div>

          <!-- Progress Indicator -->
          <div class="mb-8">
            <div class="flex justify-between mb-4">
              ${w.map((e,t)=>m`
                  <div
                    class="flex flex-col items-center flex-1"
                    key=${e.id}
                  >
                    <!-- Step Icon -->
                    <div
                      class="${t<=d?"bg-primary-500 text-white":"bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400"}
                      w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold transition-all duration-300 mb-2"
                    >
                      ${t<d?"✓":t===d?e.icon:t+1}
                    </div>
                    <!-- Step Title -->
                    <span
                      class="${t<=d?"text-gray-900 dark:text-white font-semibold":"text-gray-500 dark:text-gray-400"}
                      text-sm text-center"
                    >
                      ${e.title}
                    </span>
                    <!-- Connector Line -->
                    ${t<w.length-1&&m`
                      <div
                        class="${t<d?"bg-primary-500":"bg-gray-200 dark:bg-gray-700"}
                        h-1 w-full absolute top-6 left-1/2 -z-10 transition-all duration-300"
                        style="width: calc(100% / ${w.length} - 3rem)"
                      ></div>
                    `}
                  </div>
                `)}
            </div>
          </div>

          <!-- Step Content -->
          <div class="mb-8 min-h-[400px]">
            ${0===d&&m`
      <div class="space-y-6 animate-fadeIn">
        <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <p class="text-sm text-blue-700 dark:text-blue-300">
            <strong>WiFi Setup:</strong> Configure your WiFi network credentials
            to connect your ESP32 to the internet. Make sure you're using a
            2.4GHz network as the ESP32 doesn't support 5GHz.
          </p>
        </div>

        <${g}
          label="WiFi Network Name (SSID)"
          type="text"
          value=${n.ssid}
          onChange=${e=>p({...n,ssid:e})}
          validator=${u}
          placeholder="Enter your WiFi network name"
          required=${!0}
          helpText="Maximum 32 characters"
        />

        <div>
          <label
            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
          >
            WiFi Password
          </label>
          <input
            type="password"
            value=${n.password}
            onInput=${e=>p({...n,password:e.target.value})}
            class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border ${n.password.length>=8?"border-green-500":n.password.length>0?"border-red-500":"border-gray-300 dark:border-gray-600"} rounded-lg text-gray-900 dark:text-white"
            placeholder="Enter WiFi password"
          />
          <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
            Minimum 8 characters
          </p>
          ${n.password.length>0&&n.password.length<8&&m`
            <p class="mt-1 text-xs text-red-600 dark:text-red-400">
              Password must be at least 8 characters
            </p>
          `}
        </div>
      </div>
    `}
            ${1===d&&m`
      <div class="space-y-6 animate-fadeIn">
        <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <p class="text-sm text-blue-700 dark:text-blue-300">
            <strong>MQTT Setup:</strong> Configure your MQTT broker to enable
            communication with Home Assistant and other smart home platforms.
            You can skip this step if you don't use MQTT.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="md:col-span-2">
            <${g}
              label="MQTT Broker Address"
              type="text"
              value=${v.broker}
              onChange=${e=>k({...v,broker:e})}
              validator=${x}
              placeholder="mqtt.example.com or 192.168.1.100"
              required=${!0}
              helpText="Hostname or IP address of your MQTT broker"
            />
          </div>

          <${g}
            label="MQTT Port"
            type="number"
            value=${v.port}
            onChange=${e=>k({...v,port:e})}
            validator=${y}
            required=${!0}
            helpText="Usually 1883 for MQTT"
          />

          <div>
            <label
              class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
            >
              Username (Optional)
            </label>
            <input
              type="text"
              value=${v.username}
              onInput=${e=>k({...v,username:e.target.value})}
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              placeholder="MQTT username"
            />
          </div>

          <div class="md:col-span-2">
            <label
              class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
            >
              Password (Optional)
            </label>
            <input
              type="password"
              value=${v.password}
              onInput=${e=>k({...v,password:e.target.value})}
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              placeholder="MQTT password"
            />
          </div>
        </div>
      </div>
    `}
            ${2===d&&m`
      <div class="space-y-6 animate-fadeIn">
        <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <p class="text-sm text-blue-700 dark:text-blue-300">
            <strong>PID Tuning:</strong> Configure the PID controller parameters
            for optimal temperature regulation. The default values work well for
            most setups, but you can fine-tune them later based on your specific
            radiator and room characteristics.
          </p>
        </div>

        <div class="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
          <p class="text-sm text-yellow-700 dark:text-yellow-300">
            <strong>Note:</strong> Kp controls proportional response, Ki reduces
            steady-state error, and Kd dampens oscillations. Start with default
            values and adjust if needed.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <${g}
            label="Kp (Proportional)"
            type="number"
            step="0.1"
            value=${f.kp}
            onChange=${e=>h({...f,kp:e})}
            validator=${e=>b(e,"kp")}
            required=${!0}
            helpText="Range: 0.1 - 100"
          />

          <${g}
            label="Ki (Integral)"
            type="number"
            step="0.01"
            value=${f.ki}
            onChange=${e=>h({...f,ki:e})}
            validator=${e=>b(e,"ki")}
            required=${!0}
            helpText="Range: 0 - 10"
          />

          <${g}
            label="Kd (Derivative)"
            type="number"
            step="0.01"
            value=${f.kd}
            onChange=${e=>h({...f,kd:e})}
            validator=${e=>b(e,"kd")}
            required=${!0}
            helpText="Range: 0 - 10"
          />
        </div>
      </div>
    `}
            ${3===d&&m`
      <div class="space-y-6 animate-fadeIn">
        <div class="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
          <p class="text-sm text-green-700 dark:text-green-300">
            <strong>Review Your Configuration:</strong> Please review your
            settings before saving. You can always change these later in the
            Configuration page.
          </p>
        </div>

        <!-- WiFi Configuration Review -->
        <div class="bg-white dark:bg-gray-700 rounded-lg p-6 border border-gray-200 dark:border-gray-600">
          <h3
            class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2"
          >
            <span>📡</span>
            <span>WiFi Configuration</span>
          </h3>
          <div class="space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Network:</span>
              <span class="text-gray-900 dark:text-white font-medium"
                >${n.ssid}</span
              >
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Password:</span>
              <span class="text-gray-900 dark:text-white font-medium"
                >${"•".repeat(n.password.length)}</span
              >
            </div>
          </div>
        </div>

        <!-- MQTT Configuration Review -->
        <div class="bg-white dark:bg-gray-700 rounded-lg p-6 border border-gray-200 dark:border-gray-600">
          <h3
            class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2"
          >
            <span>📨</span>
            <span>MQTT Configuration</span>
          </h3>
          <div class="space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600 dark:text-gray-400">Broker:</span>
              <span class="text-gray-900 dark:text-white font-medium"
                >${v.broker}:${v.port}</span
              >
            </div>
            ${v.username&&m`
              <div class="flex justify-between">
                <span class="text-gray-600 dark:text-gray-400">Username:</span>
                <span class="text-gray-900 dark:text-white font-medium"
                  >${v.username}</span
                >
              </div>
            `}
          </div>
        </div>

        <!-- PID Configuration Review -->
        <div class="bg-white dark:bg-gray-700 rounded-lg p-6 border border-gray-200 dark:border-gray-600">
          <h3
            class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2"
          >
            <span>🎛️</span>
            <span>PID Configuration</span>
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div class="text-center">
              <div class="text-gray-600 dark:text-gray-400 text-sm mb-1">
                Kp
              </div>
              <div class="text-gray-900 dark:text-white font-bold text-xl">
                ${f.kp}
              </div>
            </div>
            <div class="text-center">
              <div class="text-gray-600 dark:text-gray-400 text-sm mb-1">
                Ki
              </div>
              <div class="text-gray-900 dark:text-white font-bold text-xl">
                ${f.ki}
              </div>
            </div>
            <div class="text-center">
              <div class="text-gray-600 dark:text-gray-400 text-sm mb-1">
                Kd
              </div>
              <div class="text-gray-900 dark:text-white font-bold text-xl">
                ${f.kd}
              </div>
            </div>
          </div>
        </div>
      </div>
    `}
          </div>

          <!-- Navigation Buttons -->
          <div class="flex justify-between items-center pt-6 border-t border-gray-200 dark:border-gray-700">
            <div>
              ${d>0&&m`
                <button
                  onClick=${()=>{d>0&&i(d-1)}}
                  disabled=${l}
                  class="px-6 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg font-medium transition-all disabled:opacity-50"
                >
                  ← Back
                </button>
              `}
            </div>

            <div class="flex gap-3">
              <button
                onClick=${()=>{null==r||r()}}
                disabled=${l}
                class="px-6 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white font-medium transition-all disabled:opacity-50"
              >
                Skip Setup
              </button>

              ${d<w.length-1?m`
                    <button
                      onClick=${()=>{d<w.length-1&&i(d+1)}}
                      disabled=${!(()=>{switch(d){case 0:return(()=>{const e=u(n.ssid).isValid,t=n.password.length>=8;return e&&t})();case 1:return(()=>{const e=x(v.broker).isValid,t=y(v.port).isValid;return e&&t})();case 2:return(()=>{const e=b(f.kp,"kp").isValid,t=b(f.ki,"ki").isValid,r=b(f.kd,"kd").isValid;return e&&t&&r})();case 3:return!0;default:return!1}})()||l}
                      class="px-6 py-2 bg-primary-500 hover:bg-primary-600 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-all"
                    >
                      Next →
                    </button>
                  `:m`
                    <button
                      onClick=${async()=>{o(!0);try{await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({section:"wifi",ssid:n.ssid,password:n.password})}),await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({section:"mqtt",broker:v.broker,port:parseInt(v.port),username:v.username,password:v.password})}),await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({section:"pid",kp:parseFloat(f.kp),ki:parseFloat(f.ki),kd:parseFloat(f.kd)})}),s.success("Configuration saved successfully!"),o(!1),null==a||a(),null==r||r()}catch(e){s.error(`Failed to save configuration: ${e.message}`),o(!1)}}}
                      disabled=${l}
                      class="px-6 py-2 bg-green-500 hover:bg-green-600 disabled:bg-gray-400 text-white rounded-lg font-medium transition-all flex items-center gap-2"
                    >
                      ${l?m`<${c} size="sm" color="white" />
                            <span>Saving...</span>`:m`<span>Save Configuration</span>`}
                    </button>
                  `}
            </div>
          </div>
        </div>
      </div>
    </div>
  `:null}const k=a.bind(e);function f(){var e,a,d,i;const[l,n]=t(null),[p,c]=t(!0),[u,x]=t(!1),[y,m]=t(!1),[f,h]=t(!1),[w,$]=t({kp:"2.0",ki:"0.5",kd:"1.0"}),[T,C]=t({kp:!0,ki:!0,kd:!0});r(()=>{S()},[]),r(()=>{var e,t,r;(null==l?void 0:l.pid)&&$({kp:(null==(e=l.pid.kp)?void 0:e.toString())||"2.0",ki:(null==(t=l.pid.ki)?void 0:t.toString())||"0.5",kd:(null==(r=l.pid.kd)?void 0:r.toString())||"1.0"})},[l]);const S=async()=>{try{const e=await fetch("/api/config"),t=await e.json();n(t),c(!1)}catch(e){s.error(`Failed to load config: ${e.message}`),c(!1)}},P=(e,t)=>{$(r=>({...r,[e]:t}));const r=b(t,e);C(t=>({...t,[e]:r.isValid}))},I=T.kp&&T.ki&&T.kd;return p?k`
      <div class="space-y-6">
        ${[...Array(4)].map(()=>k`
          <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 animate-pulse">
            <div class="h-6 bg-gray-200 dark:bg-gray-700 rounded w-40 mb-4"></div>
            <div class="space-y-3">
              ${[...Array(3)].map(()=>k`
                <div class="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
              `)}
            </div>
          </div>
        `)}
      </div>
    `:k`
    <div class="space-y-6">
      <!-- Getting Started Section -->
      <div class="bg-gradient-to-r from-primary-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 class="text-2xl font-bold mb-2 flex items-center gap-2">
              <span>🚀</span>
              <span>Getting Started</span>
            </h2>
            <p class="text-white/90">
              New to the ESP32 Thermostat? Use our setup wizard to configure your device step-by-step.
            </p>
          </div>
          <button
            onClick=${()=>h(!0)}
            class="px-6 py-3 bg-white text-primary-600 hover:bg-gray-100 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap self-start md:self-center"
          >
            <span>✨</span>
            <span>Launch Setup Wizard</span>
          </button>
        </div>
      </div>

      <!-- WiFi Configuration -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📡</span>
          <span>WiFi Configuration</span>
        </h2>
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              SSID
            </label>
            <input
              type="text"
              value=${(null==(e=null==l?void 0:l.wifi)?void 0:e.ssid)||""}
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              placeholder="Enter WiFi SSID"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Password
            </label>
            <input
              type="password"
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              placeholder="Enter WiFi password"
            />
          </div>
          <button
            disabled=${u}
            class="px-4 py-2 bg-primary-500 hover:bg-primary-600 disabled:bg-gray-400 text-white rounded-lg font-medium transition-all"
          >
            ${u?"Saving...":"Save WiFi Settings"}
          </button>
        </div>
      </div>

      <!-- MQTT Configuration -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📨</span>
          <span>MQTT Configuration</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Broker Address
            </label>
            <input
              type="text"
              value=${(null==(a=null==l?void 0:l.mqtt)?void 0:a.broker)||""}
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              placeholder="mqtt.example.com"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Port
            </label>
            <input
              type="number"
              value=${(null==(d=null==l?void 0:l.mqtt)?void 0:d.port)||1883}
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Username
            </label>
            <input
              type="text"
              value=${(null==(i=null==l?void 0:l.mqtt)?void 0:i.username)||""}
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Password
            </label>
            <input
              type="password"
              class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
            />
          </div>
        </div>
        <button
          disabled=${u}
          class="mt-4 px-4 py-2 bg-primary-500 hover:bg-primary-600 disabled:bg-gray-400 text-white rounded-lg font-medium transition-all"
        >
          ${u?"Saving...":"Save MQTT Settings"}
        </button>
      </div>

      <!-- PID Configuration -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>🎛️</span>
          <span>PID Configuration</span>
        </h2>

        <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4">
          <p class="text-sm text-blue-700 dark:text-blue-300">
            <strong>PID Tuning Guide:</strong> Kp controls proportional response, Ki reduces steady-state error, and Kd dampens oscillations. Adjust carefully for optimal temperature control.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <${g}
            label="Kp (Proportional)"
            type="number"
            step="0.1"
            value=${w.kp}
            onChange=${e=>P("kp",e)}
            validator=${e=>b(e,"kp")}
            helpText="Range: 0.1 - 100"
            required=${!0}
          />

          <${g}
            label="Ki (Integral)"
            type="number"
            step="0.01"
            value=${w.ki}
            onChange=${e=>P("ki",e)}
            validator=${e=>b(e,"ki")}
            helpText="Range: 0 - 10"
            required=${!0}
          />

          <${g}
            label="Kd (Derivative)"
            type="number"
            step="0.01"
            value=${w.kd}
            onChange=${e=>P("kd",e)}
            validator=${e=>b(e,"kd")}
            helpText="Range: 0 - 10"
            required=${!0}
          />
        </div>

        <div class="mt-4 flex items-center gap-3">
          <button
            onClick=${async()=>{T.kp&&T.ki&&T.kd?await(async(e,t)=>{x(!0);try{if(!(await fetch("/api/config",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({section:"pid",...t})})).ok)throw new Error("Failed to save configuration");s.success("Configuration saved successfully"),await S()}catch(r){s.error(`Failed to save config: ${r.message}`)}finally{x(!1)}})(0,{kp:parseFloat(w.kp),ki:parseFloat(w.ki),kd:parseFloat(w.kd)}):s.error("Please fix validation errors before saving")}}
            disabled=${u||!I}
            class="px-4 py-2 bg-primary-500 hover:bg-primary-600 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-all"
          >
            ${u?"Saving...":"Save PID Settings"}
          </button>

          ${!I&&k`
            <span class="text-sm text-red-600 dark:text-red-400 flex items-center gap-1">
              <span>⚠️</span>
              <span>Please fix validation errors</span>
            </span>
          `}
        </div>
      </div>

      <!-- Danger Zone -->
      <div class="bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-800 rounded-xl p-6">
        <h2 class="text-xl font-bold text-red-800 dark:text-red-300 mb-2 flex items-center gap-2">
          <span>⚠️</span>
          <span>Danger Zone</span>
        </h2>
        <p class="text-red-700 dark:text-red-400 mb-4">
          Irreversible actions that will affect your device configuration.
        </p>
        <div class="space-y-3">
          <div class="flex justify-between items-center p-4 bg-white dark:bg-gray-800 rounded-lg">
            <div>
              <h3 class="font-semibold text-gray-900 dark:text-white">Factory Reset</h3>
              <p class="text-sm text-gray-600 dark:text-gray-400">Reset all settings to factory defaults</p>
            </div>
            <button
              onClick=${()=>m(!0)}
              class="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-medium transition-all"
            >
              Reset Device
            </button>
          </div>
        </div>
      </div>

      <!-- Factory Reset Modal -->
      <${o}
        isOpen=${y}
        onClose=${()=>m(!1)}
        onConfirm=${async()=>{await fetch("/api/reset",{method:"POST"}),s.info("Device is resetting... Please wait."),setTimeout(()=>{window.location.reload()},5e3)}}
      />

      <!-- Configuration Wizard -->
      <${v}
        isOpen=${f}
        onClose=${()=>h(!1)}
        onComplete=${()=>{h(!1),S()}}
      />
    </div>
  `}export{f as C};
