import{_ as a,d as e,y as t}from"./v-preact-BAP1wjwx.js";import{h as s}from"./v-misc-CJ9EBB9u.js";const l=s.bind(a);function d(){const[a,s]=e(null),[d,n]=e(!0),[i,r]=e(null);t(()=>{o();const a=setInterval(o,1e4);return()=>clearInterval(a)},[]);const o=async()=>{try{const a=await fetch("/api/status"),e=await a.json();s(e),n(!1)}catch(a){r(a.message),n(!1)}};return d?l`
      <div class="space-y-6">
        ${[...Array(3)].map(()=>l`
          <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 animate-pulse">
            <div class="h-6 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-4"></div>
            <div class="space-y-3">
              ${[...Array(4)].map(()=>l`
                <div class="flex justify-between">
                  <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                  <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32"></div>
                </div>
              `)}
            </div>
          </div>
        `)}
      </div>
    `:i?l`
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <div class="text-center py-8">
          <div class="text-red-500 text-5xl mb-4">⚠️</div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Failed to Load Status
          </h3>
          <p class="text-gray-600 dark:text-gray-400 mb-4">${i}</p>
          <button
            onClick=${o}
            class="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"
          >
            Retry
          </button>
        </div>
      </div>
    `:l`
    <div class="space-y-6">
      <!-- System Information -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>🖥️</span>
          <span>System Information</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Uptime",value:(null==a?void 0:a.uptime)||"--",icon:"⏱️"},{label:"Free Heap",value:(null==a?void 0:a.freeHeap)||"--",icon:"💾"},{label:"Chip Model",value:(null==a?void 0:a.chipModel)||"--",icon:"🔧"},{label:"CPU Frequency",value:(null==a?void 0:a.cpuFreq)||"--",icon:"⚡"}].map(({label:a,value:e,icon:t})=>l`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${t}</span>
                <span>${a}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white">${e}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- Network Information -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📡</span>
          <span>Network Status</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"WiFi SSID",value:(null==a?void 0:a.wifiSSID)||"--",icon:"📶"},{label:"IP Address",value:(null==a?void 0:a.ipAddress)||"--",icon:"🌐"},{label:"Signal Strength",value:(null==a?void 0:a.rssi)||"--",icon:"📡"},{label:"MAC Address",value:(null==a?void 0:a.macAddress)||"--",icon:"🔖"}].map(({label:a,value:e,icon:t})=>l`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${t}</span>
                <span>${a}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white font-mono text-sm">${e}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- MQTT Status -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📨</span>
          <span>MQTT Status</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Connection",value:(null==a?void 0:a.mqttConnected)?"✅ Connected":"❌ Disconnected",icon:"🔌"},{label:"Broker",value:(null==a?void 0:a.mqttBroker)||"--",icon:"🖥️"},{label:"Client ID",value:(null==a?void 0:a.mqttClientId)||"--",icon:"🆔"},{label:"Last Message",value:(null==a?void 0:a.mqttLastMessage)||"--",icon:"📮"}].map(({label:a,value:e,icon:t})=>l`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${t}</span>
                <span>${a}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white text-sm">${e}</span>
            </div>
          `)}
        </div>
      </div>
    </div>
  `}export{d as S};
