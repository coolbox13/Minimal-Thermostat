import{_ as e,d as a,y as l}from"./v-preact-BAP1wjwx.js";import{h as i}from"./v-misc-CJ9EBB9u.js";const t=i.bind(e);function s(){var e,i,s,n,d,o,r,v,p,c,u,g,b,m,x,y,f,h,w,$,k,_,F,C,S,I,j,P,M,T,A,D,q,W,K,R,B,U,H,z,N,Q;const[L,E]=a(null),[V,Y]=a(!0),[G,J]=a(null);l(()=>{O();const e=setInterval(O,1e4);return()=>clearInterval(e)},[]);const O=async()=>{try{const e=await fetch("/api/status"),a=await e.json();E(a),Y(!1)}catch(e){J(e.message),Y(!1)}};if(V)return t`
      <div class="space-y-6">
        ${[...Array(3)].map(()=>t`
          <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 animate-pulse">
            <div class="h-6 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-4"></div>
            <div class="space-y-3">
              ${[...Array(4)].map(()=>t`
                <div class="flex justify-between">
                  <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                  <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32"></div>
                </div>
              `)}
            </div>
          </div>
        `)}
      </div>
    `;if(G)return t`
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <div class="text-center py-8">
          <div class="text-red-500 text-5xl mb-4">⚠️</div>
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Failed to Load Status
          </h3>
          <p class="text-gray-600 dark:text-gray-400 mb-4">${G}</p>
          <button
            onClick=${O}
            class="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"
          >
            Retry
          </button>
        </div>
      </div>
    `;const X=e=>e?e<1e3?`${e}ms`:e<6e4?`${(e/1e3).toFixed(1)}s`:e<36e5?`${(e/6e4).toFixed(1)}min`:`${(e/36e5).toFixed(1)}h`:"--";return t`
    <div class="space-y-6">
      <!-- System Information -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>🖥️</span>
          <span>System Information</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Uptime",value:(e=>{if(!e)return"--";const a=Math.floor(e/86400),l=Math.floor(e%86400/3600),i=Math.floor(e%3600/60),t=e%60;return a>0?`${a}d ${l}h ${i}m`:l>0?`${l}h ${i}m ${t}s`:i>0?`${i}m ${t}s`:`${t}s`})(null==(e=null==L?void 0:L.system)?void 0:e.uptime),icon:"⏱️"},{label:"Free Heap",value:(null==(i=null==L?void 0:L.system)?void 0:i.free_heap)?`${(L.system.free_heap/1024).toFixed(1)} KB`:"--",icon:"💾"},{label:"Total Heap",value:(null==(s=null==L?void 0:L.system)?void 0:s.total_heap)?`${(L.system.total_heap/1024).toFixed(1)} KB`:"--",icon:"💾"},{label:"Chip Model",value:(null==(n=null==L?void 0:L.system)?void 0:n.chip_model)||"--",icon:"🔧"},{label:"CPU Frequency",value:(null==(d=null==L?void 0:L.system)?void 0:d.cpu_freq_mhz)?`${L.system.cpu_freq_mhz} MHz`:"--",icon:"⚡"},{label:"Free Flash",value:(null==(o=null==L?void 0:L.system)?void 0:o.free_flash_kb)?`${L.system.free_flash_kb} KB`:"--",icon:"💿"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white">${a}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- Network Information -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📡</span>
          <span>Network Status</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"WiFi SSID",value:(null==(r=null==L?void 0:L.wifi)?void 0:r.ssid)||"--",icon:"📶"},{label:"IP Address",value:(null==(v=null==L?void 0:L.wifi)?void 0:v.ip)||"--",icon:"🌐"},{label:"Signal Strength",value:(null==(p=null==L?void 0:L.wifi)?void 0:p.rssi)?`${L.wifi.rssi} dBm`:"--",icon:"📡"},{label:"Signal Quality",value:(null==(c=null==L?void 0:L.wifi)?void 0:c.quality)?`${L.wifi.quality}%`:"--",icon:"📊"},{label:"MAC Address",value:(null==(u=null==L?void 0:L.wifi)?void 0:u.mac)||"--",icon:"🔖"},{label:"Connected",value:(null==(g=null==L?void 0:L.wifi)?void 0:g.connected)?"✅ Yes":"❌ No",icon:"🔌"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white font-mono text-sm">${a}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- MQTT Status -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>📨</span>
          <span>MQTT Configuration</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Server",value:(null==(b=null==L?void 0:L.mqtt)?void 0:b.server)||"--",icon:"🖥️"},{label:"Port",value:(null==(m=null==L?void 0:L.mqtt)?void 0:m.port)||"--",icon:"🔌"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white font-mono text-sm">${a}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- Timing Intervals -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>⏱️</span>
          <span>Timing Intervals</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Sensor Update",value:X(null==(x=null==L?void 0:L.timing)?void 0:x.sensor_update_interval),icon:"🌡️"},{label:"History Update",value:X(null==(y=null==L?void 0:L.timing)?void 0:y.history_update_interval),icon:"📊"},{label:"PID Update",value:X(null==(f=null==L?void 0:L.timing)?void 0:f.pid_update_interval),icon:"🎛️"},{label:"Connectivity Check",value:X(null==(h=null==L?void 0:L.timing)?void 0:h.connectivity_check_interval),icon:"🔍"},{label:"PID Config Write",value:X(null==(w=null==L?void 0:L.timing)?void 0:w.pid_config_write_interval),icon:"💾"},{label:"WiFi Connect Timeout",value:(null==($=null==L?void 0:L.timing)?void 0:$.wifi_connect_timeout)?`${L.timing.wifi_connect_timeout}s`:"--",icon:"⏳"},{label:"Max Reconnect Attempts",value:(null==(k=null==L?void 0:L.timing)?void 0:k.max_reconnect_attempts)||"--",icon:"🔄"},{label:"System Watchdog",value:X(null==(_=null==L?void 0:L.timing)?void 0:_.system_watchdog_timeout),icon:"🐕"},{label:"WiFi Watchdog",value:X(null==(F=null==L?void 0:L.timing)?void 0:F.wifi_watchdog_timeout),icon:"📡"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white">${a}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- PID Configuration -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>🎛️</span>
          <span>PID Configuration</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Kp",value:(null==(S=null==(C=null==L?void 0:L.pid)?void 0:C.kp)?void 0:S.toFixed(3))||"--",icon:"📈"},{label:"Ki",value:(null==(j=null==(I=null==L?void 0:L.pid)?void 0:I.ki)?void 0:j.toFixed(3))||"--",icon:"📊"},{label:"Kd",value:(null==(M=null==(P=null==L?void 0:L.pid)?void 0:P.kd)?void 0:M.toFixed(3))||"--",icon:"📉"},{label:"Setpoint",value:(null==(T=null==L?void 0:L.pid)?void 0:T.setpoint)?`${L.pid.setpoint.toFixed(1)}°C`:"--",icon:"🎯"},{label:"Deadband",value:(null==(A=null==L?void 0:L.pid)?void 0:A.deadband)?`${L.pid.deadband.toFixed(2)}°C`:"--",icon:"📏"},{label:"Valve Position",value:void 0!==(null==(D=null==L?void 0:L.pid)?void 0:D.valve_position)?`${L.pid.valve_position}%`:"--",icon:"🔧"},{label:"Adaptation Interval",value:(null==(q=null==L?void 0:L.pid)?void 0:q.adaptation_interval)?`${L.pid.adaptation_interval}s`:"--",icon:"⏱️"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white">${a}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- Presets -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>🌡️</span>
          <span>Temperature Presets</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Current Preset",value:(null==(W=null==L?void 0:L.presets)?void 0:W.current)||"--",icon:"📍"},{label:"Eco",value:(null==(K=null==L?void 0:L.presets)?void 0:K.eco)?`${L.presets.eco.toFixed(1)}°C`:"--",icon:"🌱"},{label:"Comfort",value:(null==(R=null==L?void 0:L.presets)?void 0:R.comfort)?`${L.presets.comfort.toFixed(1)}°C`:"--",icon:"😊"},{label:"Away",value:(null==(B=null==L?void 0:L.presets)?void 0:B.away)?`${L.presets.away.toFixed(1)}°C`:"--",icon:"🏠"},{label:"Sleep",value:(null==(U=null==L?void 0:L.presets)?void 0:U.sleep)?`${L.presets.sleep.toFixed(1)}°C`:"--",icon:"😴"},{label:"Boost",value:(null==(H=null==L?void 0:L.presets)?void 0:H.boost)?`${L.presets.boost.toFixed(1)}°C`:"--",icon:"🔥"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white">${a}</span>
            </div>
          `)}
        </div>
      </div>

      <!-- Diagnostics -->
      <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <span>🔍</span>
          <span>Diagnostics</span>
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          ${[{label:"Last Reboot Reason",value:(null==(z=null==L?void 0:L.diagnostics)?void 0:z.last_reboot_reason)||"--",icon:"🔄"},{label:"Reboot Count",value:(null==(N=null==L?void 0:L.diagnostics)?void 0:N.reboot_count)||"--",icon:"🔢"},{label:"Watchdog Reboots",value:(null==(Q=null==L?void 0:L.diagnostics)?void 0:Q.consecutive_watchdog_reboots)||"--",icon:"🐕"}].map(({label:e,value:a,icon:l})=>t`
            <div class="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <span class="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <span>${l}</span>
                <span>${e}</span>
              </span>
              <span class="font-semibold text-gray-900 dark:text-white">${a}</span>
            </div>
          `)}
        </div>
      </div>
    </div>
  `}export{s as S};
